﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SSGS_EMS_Test_Project
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
