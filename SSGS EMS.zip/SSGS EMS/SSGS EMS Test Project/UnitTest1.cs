﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
//using NUnit.Framework;
using SSGS_Password_Validator;

namespace SSGS_EMS_Test_Project
{
    //[TestFixture]
    //public class NUnitTestClass
    //{
    //    [Test]
    //    public void NUnitTest()
    //    {
    //        PwdValidator target = new PwdValidator();
    //        string password = "password";
    //        bool expected = true;
    //        bool actual;
    //        actual = target.PasswdValidation(password);
    //        NUnit.Framework.Assert.AreEqual(actual, expected);
    //    }
    //}
}
